# Kwantum Institute Website

Created with React, Vite, and Django

**Instructions on how to add new article is within the frontend folder**