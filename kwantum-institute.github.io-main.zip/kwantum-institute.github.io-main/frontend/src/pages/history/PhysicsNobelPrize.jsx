import Article from "../Article";

function PhysicsNobelPrize() {
  return (
    <Article
      topic="History Celebration"
      title="Physics Nobel Prize"
      name="Tommy"
      date="12/4/2003"
      subtitle="Hello"
      content={
        <>
          <p>Your content here...</p>
        </>
      }
    />
  );
}

export default PhysicsNobelPrize;
